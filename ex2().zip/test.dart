class Point {
  int x = 0;
  int y = 0;

  Point(int x, int y) {
    
    this.x = x;
    this.y = y;
  }
}
void main() {

  var location = new Point(36,87);

}
